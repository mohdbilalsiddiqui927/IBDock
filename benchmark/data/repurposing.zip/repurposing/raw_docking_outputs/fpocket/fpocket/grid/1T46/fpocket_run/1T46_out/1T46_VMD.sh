#!/bin/bash
vmd 1T46_out.pdb -e 1T46.tcl
