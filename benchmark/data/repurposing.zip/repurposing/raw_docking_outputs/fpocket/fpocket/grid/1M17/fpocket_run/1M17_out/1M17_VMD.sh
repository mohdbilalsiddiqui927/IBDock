#!/bin/bash
vmd 1M17_out.pdb -e 1M17.tcl
