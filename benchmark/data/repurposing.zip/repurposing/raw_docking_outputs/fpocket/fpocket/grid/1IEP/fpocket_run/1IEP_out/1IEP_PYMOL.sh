#!/bin/bash
pymol 1IEP.pml
