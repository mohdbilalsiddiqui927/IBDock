#!/bin/bash
vmd 1IEP_out.pdb -e 1IEP.tcl
