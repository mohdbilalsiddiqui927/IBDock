#!/bin/bash
pymol 1M17.pml
