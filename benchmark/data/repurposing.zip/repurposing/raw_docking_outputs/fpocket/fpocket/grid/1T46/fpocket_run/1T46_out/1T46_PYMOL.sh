#!/bin/bash
pymol 1T46.pml
