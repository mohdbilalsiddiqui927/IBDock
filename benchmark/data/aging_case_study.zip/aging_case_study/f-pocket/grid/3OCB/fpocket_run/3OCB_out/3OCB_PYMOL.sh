#!/bin/bash
pymol 3OCB.pml
