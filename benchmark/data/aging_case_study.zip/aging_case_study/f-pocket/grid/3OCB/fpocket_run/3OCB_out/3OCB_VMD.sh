#!/bin/bash
vmd 3OCB_out.pdb -e 3OCB.tcl
