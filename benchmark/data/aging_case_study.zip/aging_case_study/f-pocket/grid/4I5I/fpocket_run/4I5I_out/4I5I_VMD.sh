#!/bin/bash
vmd 4I5I_out.pdb -e 4I5I.tcl
