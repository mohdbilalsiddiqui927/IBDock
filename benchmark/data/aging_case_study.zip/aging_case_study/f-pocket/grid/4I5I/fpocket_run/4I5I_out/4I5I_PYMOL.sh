#!/bin/bash
pymol 4I5I.pml
