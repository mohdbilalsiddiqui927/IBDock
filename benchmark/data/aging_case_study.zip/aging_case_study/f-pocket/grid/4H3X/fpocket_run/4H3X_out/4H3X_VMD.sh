#!/bin/bash
vmd 4H3X_out.pdb -e 4H3X.tcl
