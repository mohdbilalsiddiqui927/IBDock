#!/bin/bash
pymol 4H3X.pml
