#!/bin/bash
vmd 6VGL_out.pdb -e 6VGL.tcl
