#!/bin/bash
pymol 6VGL.pml
