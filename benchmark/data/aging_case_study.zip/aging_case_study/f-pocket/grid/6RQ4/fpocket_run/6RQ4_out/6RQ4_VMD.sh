#!/bin/bash
vmd 6RQ4_out.pdb -e 6RQ4.tcl
