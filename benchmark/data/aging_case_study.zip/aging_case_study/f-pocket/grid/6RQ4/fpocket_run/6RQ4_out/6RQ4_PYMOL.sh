#!/bin/bash
pymol 6RQ4.pml
