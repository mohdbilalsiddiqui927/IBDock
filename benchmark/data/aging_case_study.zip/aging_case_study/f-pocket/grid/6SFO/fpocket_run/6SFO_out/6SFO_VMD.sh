#!/bin/bash
vmd 6SFO_out.pdb -e 6SFO.tcl
