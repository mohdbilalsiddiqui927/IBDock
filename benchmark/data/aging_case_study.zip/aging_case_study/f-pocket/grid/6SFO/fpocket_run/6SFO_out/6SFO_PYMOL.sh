#!/bin/bash
pymol 6SFO.pml
