#!/bin/bash
pymol 1ERR.pml
