#!/bin/bash
vmd 1ERR_out.pdb -e 1ERR.tcl
