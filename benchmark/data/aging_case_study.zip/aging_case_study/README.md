# Aging-associated case study (7 complexes)
Raw inputs and outputs behind Table S5, Table S5b/S5c and Figure 8 of the manuscript.

- `raw_proteins/`, `raw_ligands/`: input structures (1ERR, 3OCB, 4H3X, 4I5I, 6RQ4, 6SFO, 6VGL).
- `prepared_receptors/`, `prepared_ligands/`: PDBQT inputs used for Vina.
- `co_crystallized/`, `f-pocket/`, `p2rank/`, `Blind/`: `grid/` (box definitions), `docking/` (Vina output poses, PDBQT), `results/` (Vina logs). Each of the 4 strategies has 7 self-docking runs (28 conditions, Table S5); `p2rank/` additionally has all 49 ligand x receptor dockings (Tables S5b/S5c; `p2rank/results/docking_results.csv`).
- `Validation_Redocking_Results_7_Complexes.docx`: RMSD summary table.
- `IBDock_config.json`: tool configuration used by the application.

All runs: AutoDock Vina 1.2.7, exhaustiveness 16, random seed 42, one run per condition (confirmed from the logs). Local absolute paths in the logs were shortened to `case_study\`.
